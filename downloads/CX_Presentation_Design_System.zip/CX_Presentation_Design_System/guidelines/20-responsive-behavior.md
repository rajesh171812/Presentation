# Responsive behavior

Design mobile first. Breakpoints: mobile under 768px, tablet 768 to 1023px, desktop 1024px and up. The grid is 4, 8 and 12 columns (`--grid-columns`). Page max 1440px, content container 1200px. Use the literal values 768px, 1024px and 1440px in `@media` rules.

| Element | Mobile | Tablet | Desktop |
|---|---|---|---|
| Navigation | menu button with an off-canvas panel, or a bottom nav (max 5) | 72px icon rail | 264px sidebar |
| Cards | 1 per row | 2 per row | 3 to 4 per row |
| Tables | scroll in a labeled container, or rows become cards | hide low-priority columns | all columns |
| Modals | full-width bottom sheet | centered dialog | centered dialog, max 480px |
| Charts | simplified, legend below, data table available | legend below | full detail |
| Buttons | lone primary full width, stacked pair full width | natural | natural |
| Filters | a "Filters" button opens a sheet | inline | inline or left panel |

- Multi-column content stacks in reading order below 768px.
- Never hide the primary action, an error or task-critical information; move it instead.
- On touch devices (`pointer: coarse`) buttons grow to 44px (small 40, large 52) and inputs to 44px.
- Test at 320px, 768px and 1280px widths with no horizontal page scroll.
