# Workflow and gates

Never jump from input to slides.

| Step | What happens |
|---|---|
| STEP-01 User intent | Owner shares objective, audience, context, data, research, quotes, screenshots. |
| STEP-02 AI understanding | Why, for whom, what decision, what evidence exists, level of detail. |
| STEP-03 Story strategy | Pick a presentation type and story structure; draft the Story Proposal. |
| GATE-01 Story approval | Only an explicit approval unlocks the next step. Silence or partial feedback is not approval. |
| STEP-04 Presentation blueprint | Map every slide to SLD, CMP, VIZ, DEVICE, MSG and ICN IDs. |
| GATE-02 Governance exception | Any Restricted or Missing element waits for the owner's approval or a substitute; usually settled here, can open at any step. |
| STEP-05 Governed assembly | Build the .pptx from approved elements only. |
| STEP-06 Governance check | Story, design, assets, visualization, content and PowerPoint QC. |
| GATE-03 Final human review | Owner reviews, edits and signs off. |
| STEP-07 Final presentation | Deliver the .pptx with the story used, exceptions and gaps. |
