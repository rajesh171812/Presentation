# Definition of done

Every generated screen meets all of these before it is finished:

- [ ] Only CX Presentation Design System components and tokens; no hex values, no raw px for spacing, radius or type.
- [ ] Works in light and dark, and at 320px, 768px and 1280px widths without horizontal page scroll.
- [ ] A keyboard-only walkthrough completes the main task; focus is always visible.
- [ ] One `h1`; no skipped heading levels; landmarks (`header`, `nav`, `main`).
- [ ] Loading, empty and error states exist for every data view.
- [ ] Copy follows the content fundamentals in the README: sentence case, verb plus object on buttons, errors that say what happened and how to fix it.

## Component contract format

Every component is specified in this shape so it can be reproduced exactly:

```
Component:  Button
Purpose:    Trigger an action within a workflow.
Variants:   primary | secondary | tertiary | ghost | destructive
Sizes:      sm (32) | md (40, default) | lg (48)
States:     default, hover, pressed, focus, disabled, loading
Rules:      One primary per section. Label = verb + object. Loading keeps width, sets aria-busy.
Responsive: A lone primary is full width below 768px.
A11y:       Native <button>; 2px focus ring; 4.5:1 label contrast in both themes.
Code:       <button class="bl-btn bl-btn--primary" type="button">Create account</button>
```
