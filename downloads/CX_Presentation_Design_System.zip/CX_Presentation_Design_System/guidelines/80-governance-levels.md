# Governance levels

Every element carries one status; the badge always shows an icon and a word.

| Level | Rule |
|---|---|
| Approved | Use it automatically. |
| Conditional | Use it only when its stated condition is met. |
| Restricted | Needs the owner's approval for each use. Proposed drafts start here. |
| Deprecated | Not used in new presentations (none at present). |
| Missing | Needed but not in the library: flag it at GATE-02, never improvise it. |

Representation hierarchy: reuse an approved asset → assemble from an approved component → follow an approved pattern → adapt the closest approved pattern → flag the gap.
