# Forms and states

## Forms

- One column. Structure a field as `.bl-field > label.bl-label + (p.bl-help) + input.bl-input + (p.bl-error)`.
- Mark optional fields "(optional)" with `bl-label__opt`; do not use asterisks alone.
- Validate on blur (format) and on submit (completeness). Do not clear an input after an error.
- On submit with errors, show an error summary (`role="alert"`), set `aria-invalid="true"` and `aria-describedby` on each invalid input, and move focus to the first invalid field.
- Set `type` and `autocomplete` correctly. Inputs use at least 16px text on mobile (`--font-body` is 16px).
- Every error has an icon and text, in `color-status-error-fg`; the invalid input gets a 2px `color-status-error-solid` border.

## Buttons in forms

- One primary button per section. The label is verb plus object ("Create account"), never "Submit" or "OK".
- Variants: `bl-btn--primary`, `--secondary`, `--tertiary`, `--ghost`, `--destructive`. Sizes: default 40px, `--sm` 32px, `--lg` 48px.
- Loading: set `aria-busy="true"`, show `bl-spinner bl-spinner--sm`, keep the button width and focus.
- A lone primary is full width below 768px; a stacked pair is full width too.

## Required states

- Every interactive component has default, hover, focus, active, disabled, loading (if it works asynchronously) and error (if it takes input).
- Every data view has loading (skeleton), empty (explain and give a next action) and error (what happened and a retry).
- Express state with `aria-busy`, `aria-invalid`, `aria-disabled`, `aria-selected` and `aria-current`, not with classes alone. The `is-hover`, `is-active` and `is-focus` classes exist only for documentation.
