The design system for customer-experience presentations and the pages around them: Abbott brand colors on a proven token and `bl-` component structure (inherited from Baseline), plus presentation components (slide templates, KPI, insight and quote cards, journey map, device frames, messaging, rounded icons) and the storytelling and governance rules an AI must follow when it builds a CX deck. The class prefix stays `bl-` so existing Baseline markup keeps working; only the tokens differ.

## Hard rules

1. **Use existing components.** Never invent a new button, input, card, alert, badge or table style when one exists. If none fits, say so and propose an addition instead of improvising a one-off. Combobox, date picker, file upload, menu/dropdown and drawer are specified but not built.
2. **Use tokens, never raw values.** No hex or rgb colors, no px spacing, font sizes, radii, shadows, durations or z-indexes in product code. Use the CSS variables, and the **semantic** color tokens (`--color-text-primary`), never the primitives (`--color-neutral-900`).
3. **Every interactive element** has a visible focus state, an accessible name and a 44px touch target on touch devices. Prefer native HTML over ARIA.
4. **Never rely on color alone.** Errors have an icon and text, selected items an outline or check, status badges an icon or a word.
5. **Every input has a visible, persistent `<label>`.** Placeholders are examples, not labels.
6. **Support light and dark** by using semantic tokens only. Never add a theme-specific color inline.
7. **Respect `prefers-reduced-motion`.** Animate only state changes the person caused, using the duration and easing tokens.
8. **When unsure, ask or take the more conservative existing pattern, and state your assumption.** Do not silently invent components, tokens or copy conventions.

## Setup

Load `tokens.css`, then the component stylesheet (`bundle.css`), and set `class="bl-body"` on `<body>`. Load the three Google fonts (Bricolage Grotesque, Hanken Grotesk, IBM Plex Mono) or replace them by changing `--font-family-*`. Light is the default theme; set `data-theme="dark"` on `<html>` for dark. Token names read `category-role-property-state` in CSS (`--color-action-primary-bg-hover`).

## Content fundamentals

- Sentence case everywhere: headings, buttons, tabs, labels. Buttons name the outcome: verb plus object ("Create account", "Send invoice"), never "Submit" or "OK".
- Use one word for one thing throughout ("project", "sign in"; "delete" means permanent, "remove" means detach).
- Errors say what happened and how to fix it, without apologizing or blaming. Not "Something went wrong." but "We couldn't save your changes. Check your connection and try again."
- Empty states say what this is, why it is empty and offer one action: "No invoices yet. Invoices you send will appear here." with a Create invoice button.
- Confirmation dialogs: the title is action plus object ("Delete project?"), the body is the consequence, the buttons repeat the verb ("Delete project" / "Keep project").
- Numerals for quantities with thousands separators, currency with a symbol and two decimals ($1,240.00), unambiguous dates ("14 October 2026"). Mark optional fields "(optional)", never an asterisk alone.
- Regulated language (health, legal, financial): do not invent it; use the terms supplied by the responsible specialist.

## Color

- Text is `color-text-primary` by default, `color-text-secondary` for help text, captions and placeholders, `color-text-link` for links (always underlined). `color-text-disabled` is for disabled controls only, and is below 4.5:1 by design.
- Grounds: `color-background-default` for the page, `color-surface-default` for cards, inputs and tables, `color-surface-elevated` for dialogs, `color-surface-sunken` for recessed areas (code chips, table headers), `color-surface-inverse` with `color-text-inverse` for toasts and tooltips.
- Borders: `color-border-default` separates (decorative), `color-border-strong` bounds controls, `color-border-focus` draws the 2px focus ring.
- Brand: **Medium Blue** `#004F71` (`primary-700`) is the action color: primary buttons, links, focus ring, selected state. **Abbott Blue** `#009CDE` (`primary-500`) is the brand highlight for large fills, chart series and icon ink on dark grounds; it is never a text or button color on white (3.1:1). **Dark Blue** `#002A3A` (`primary-900`) is the ground for title and section slides, the inverse surface and dark panels. **Mint** `#64CCC9` (`color-accent-bg` with `color-accent-text` Charcoal) is the one highlight per slide.
- Semantic mapping: primary action = `primary.700` in light and `primary.300` (Light Blue) in dark. Change a brand color by changing primitive steps, not by re-pointing semantic tokens.
- Neutrals come from the brand grays: Charcoal `#222731` text, Dark Gray `#63666A` secondary text, Medium Gray `#888B8D` control borders, Light Gray `#D9D9D6` dividers, White cards. Page ground `#F4F4F2` and sunken `#ECECEA` are derived tints. Abbott Black `#000000` is for a logo or wordmark only.
- Status: use the four sets `color-status-{success,warning,error,info}-{fg,bg,border,solid}`. `fg` is text on `bg`; `solid` is an icon or marker at 3:1 or more; always pair with an icon and a word. Markers use the brand colors (Medium Green `#00B140`, Orange `#FF6900`, Red `#E4002B`, Abbott Blue); the text shades `#007A2C`, `#A84600` and `#B00021` are derived because the brand green and orange fall below 4.5:1 on white.
- Charts: use `color-dataviz-1` to `color-dataviz-6` in order (Medium Blue, Abbott Blue, Coral, Purple, Magenta, Medium Green; lighter versions in dark), and also tell series apart by label, shape or pattern. Series 2, 3 and 6 sit near 3:1 on white, so always direct-label them.
- Reserved brand colors (no role yet): Light Blue `#5BC2E7` (dark-mode action), Gold `#EEB33B`, Yellow `#FFD100`, Light Green `#7CCC6C` (dark-mode success). Add a role before using them.
- Selection and hover: `color-state-hover`, `color-state-active`, `color-state-selected-bg` with `color-state-selected-border`, and the `color-state-disabled-*` pair.

## Typography

Headings use Bricolage Grotesque (`--font-family-display`), everything else Hanken Grotesk (`--font-family-sans`), code IBM Plex Mono (`--font-family-mono`). Apply a style with `font: var(--font-body); letter-spacing: var(--letter-spacing-body);`, or with the `bl-*` classes.

| Token | Size / line | Weight | Use |
|---|---|---|---|
| `--font-display` | 56 / 60 | 700 | Marketing hero, one per page |
| `--font-h1` | 40 / 48 | 700 | Page title, one per page |
| `--font-h2` | 32 / 40 | 600 | Major section |
| `--font-h3` | 24 / 32 | 600 | Sub-section, card title, dialog title |
| `--font-h4` | 20 / 28 | 600 | Group heading, small card title |
| `--font-body-lg` | 18 / 28 | 400 | Lead paragraph |
| `--font-body` | 16 / 24 | 400 | Default text, paragraphs, table cells |
| `--font-body-sm` | 14 / 20 | 400 | Secondary text, help text, dense UI |
| `--font-label` | 14 / 20 | 500 | Form labels, tabs, nav items |
| `--font-caption` | 12 / 16 | 400 | Timestamps, metadata, chart axis text |
| `--font-button` | 14 / 20 | 600 | Button labels (large button 16 / 24) |
| `--font-code` | 13 / 20 | 400 | Inline code, token names, code blocks |

One `h1` per page and no skipped heading levels: restyle with `bl-h1` to `bl-h4` instead. Body lines stay under 68ch (`--layout-prose-max`). Display, h1, h2 and h3 shrink below 768px.

## Spacing, layout and shape

- Spacing is a 4px scale (`--space-1` 4px to `--space-11` 96px). Use `--space-3` to `--space-5` for component padding, `--space-2` for icon gaps, `--space-4` between form fields, `--space-5` for card padding and `--space-8` to `--space-10` between page sections.
- Page margin and grid: 16px and 4 columns on mobile, 24px and 8 columns on tablet, 32px and 12 columns on desktop (`--grid-margin`, `--grid-columns`). Page max 1440px, content container 1200px.
- Radius: `--radius-sm` 4 (checkboxes, code chips), `--radius-md` 8 (buttons, inputs, alerts), `--radius-lg` 12 (cards), `--radius-xl` 16 (dialogs), `--radius-full` (avatars, pills, badges).
- Borders: `--border-width-1` for dividers and outlines, `--border-width-2` for the focus ring, selected and error states.
- Elevation: `--shadow-1` card, `--shadow-2` dropdown and popover, `--shadow-3` modal, `--shadow-4` toast. Never stack shadows: a card inside a card is `bl-card--flat`.
- Layers: `--z-sticky` 100, `--z-dropdown` 200, `--z-overlay` 300, `--z-modal` 400, `--z-toast` 500, `--z-tooltip` 600.
- Motion: `--duration-fast` 120ms for hover and toggles, `--duration-normal` 240ms for menus and accordions, `--duration-slow` 400ms for dialogs and progress; `--easing-standard` by default, `--easing-enter` and `--easing-exit` for arrivals and departures.

## Iconography

Icons are Lucide outline icons, inlined as SVG with `viewBox="0 0 24 24"`, stroked with `currentColor` at `--icon-stroke` (1.75). Sizes: `--icon-xs` 12, `--icon-sm` 16, `--icon-md` 20 (default), `--icon-lg` 24, `--icon-xl` 32, applied with the `bl-icon` class and its size modifiers. Icons never carry meaning alone. No logo or brand mark ships with this system: set the product name in plain type until one is supplied.

## Photography

Photography prints in pure black and white; color stays with the interface, never the picture. `bl-photo-frame` crops (fixed `aspect-ratio` or height, `overflow: hidden`); `bl-photo` on the `<img>` applies the grayscale and the crop; `bl-scrim-photo` is a theme-following gradient for the rare case where text sits on top of a photo. Crop to 16:9, 4:3, 3:4 or 1:1 and never distort the source. Full rules, including alt text and captions, are in the Imagery guideline and the Photography component.

The same tokens extend to a full slide deck or a landing page through the Templates component (`tpl-*` classes) — a section-divider pattern, bulleted and columned slides, charts, five photo treatments, and a landing page's hero, stat band, card grid and footer, all reading this system's existing colors, type and spacing rather than a one-off stylesheet.

## Brand palette

| Brand color | Hex | Token | Role |
|---|---|---|---|
| Abbott Blue | `#009CDE` | `primary-500`, `dataviz-2`, `status-info-solid` | Brand highlight, large fills, charts |
| Medium Blue | `#004F71` | `primary-700` → `action-primary-bg`, `text-link`, `border-focus` | Buttons, links, emphasis |
| Dark Blue | `#002A3A` | `primary-900` → `surface-inverse` | Title and section slides, dark panels |
| Light Blue | `#5BC2E7` | `primary-300` | Dark-mode action and links |
| Mint | `#64CCC9` | `accent-500` → `accent-bg` | One highlight per slide |
| Charcoal | `#222731` | `neutral-900` → `text-primary` | Text |
| Dark Gray | `#63666A` | `neutral-600` → `text-secondary` | Secondary text |
| Medium Gray | `#888B8D` | `neutral-500` → `border-strong` | Control borders |
| Light Gray | `#D9D9D6` | `neutral-200` → `border-default` | Dividers |
| Medium Green / Orange / Red | `#00B140` / `#FF6900` / `#E4002B` | `status-*-solid` | Status markers |
| Coral / Purple / Magenta | `#E56A54` / `#470A68` / `#AA0061` | `dataviz-3..5` | Chart series |

## Presentation layer

These components and guidelines turn the tokens into CX decks. A deck is 16:9, 1280 × 720 design canvas (13.333 × 7.5 in); slide type sizes are canvas pixels (× 0.75 for PowerPoint points).

- **SlideTemplates**: the governed slide layouts (`SLD-*` IDs) with wireframes.
- **PresentationCards**: KPI, metric, insight, evidence, quote and customer cards (`CMP-*`).
- **JourneyMap**: stages across; actions, feelings, pain points or changes down.
- **DeviceFrames**: transparent iPhone, iPad, MacBook and browser frames with measured screen areas (asset group *Device frames*).
- **Messaging**: SMS, RCS, iMessage and lock-screen drafts. Restricted: each use needs the owner's approval.
- **IconTile**: the three icon variants. **Rounded (`ICN-*-RD`) is the default on slides**; outline is for icons inside pills, badges and tables.
- Guidelines: *Storytelling* (13 rules), *Workflow and gates* (STEP-01 to STEP-07, GATE-01 to GATE-03), *Governance levels*.

The full registry of IDs, statuses and slide sequences lives in the project's `cx-presentation-system.md` spec; this system is its visual foundation.

## Component selection

| Need | Use |
|---|---|
| A photograph in product UI, a slide or a page | `bl-photo-frame` + `bl-photo` (Photography) |
| A slide deck or a landing page | `tpl-*` layout classes (Templates) |
| Compare 5+ records across the same attributes | `bl-table` (Table) |
| Fewer than 5 records, or rich content per item | `bl-card` list (Card) |
| Choose 1 of 2 to 5 options | radio group in a `bl-fieldset` (Radio) |
| Choose 1 of many | `bl-select` (Select); a combobox if searchable (not built) |
| On/off that applies immediately | `bl-switch` (Switch) |
| On/off that needs a Save button | `bl-check` (Checkbox) |
| Message tied to a place on the page | `bl-alert` (Alert) |
| Confirmation of an action just taken | `bl-toast` (Toast), with Undo if reversible |
| Irreversible action | `dialog.bl-dialog` confirmation (Dialog) |
| Page-wide or account-wide state | `bl-alert bl-alert--banner` |
| Wait, unknown length, short | `bl-spinner` with a text label (Spinner) |
| Wait, content layout known | `bl-skeleton` (Skeleton) |
| Wait, known length | `bl-progress` (Progress) |
| Status of an item | `bl-badge` with an icon or word (Badge) |
| User-applied, removable label | `bl-tag` (Tag) |

Read a component's guideline before using it: each states its variants, sizes, states, rules, responsive behavior, accessibility and a code sample. Deeper guidance is in the sections on forms and states, responsive behavior, AI features and the definition of done.
