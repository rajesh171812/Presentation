A top bar at least 56px tall with the surface fill, a bottom border and horizontal padding that follows the page margin.

```
Component:  Header
Purpose:    Hold the brand, primary links and account controls at the top of a page.
Parts:      header.bl-header > brand + links + account controls (contents are yours; gap is space-4)
Rules:      The header supplies height, padding (--grid-margin: 16 / 24 / 32), fill and border only; lay out its children with flex.
            Landmarks: use <header> for the bar and <nav> around its links. Keep the primary action reachable at every width;
            on mobile move links into a menu button rather than dropping them.
A11y:       Icon-only controls need aria-label. Focus rings apply to every control in the bar.
Code:       <header class="bl-header"><a class="bl-h4" href="/">CX Presentation Design System</a><nav aria-label="Primary">...</nav></header>
```
