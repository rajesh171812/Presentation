Layout classes for a full deck or a landing page — the kicker-and-rule header, section dividers, the five photo treatments, and the landing sections (hero, principles, stat band, cards, split, quote, steps, footer). Everything here reads existing tokens and `bl-*` classes; nothing redefines one. The only new values are a handful of `--tpl-*` display sizes (`--tpl-text-hero`, `--tpl-text-stat`, `--tpl-text-numeral`, `--tpl-text-lead`, `--tpl-text-quote`) for type larger than the UI ramp goes.

```
Component:  Templates
Purpose:    Build a slide deck or a landing page in CX Presentation Design System without leaving the token system.
Classes:    Deck — bl-slide, tpl-head/tpl-title/tpl-body/tpl-foot, tpl-divider (section divider),
            tpl-bullets, tpl-cols, tpl-quad, tpl-table-wrap, tpl-stat, tpl-chart, tpl-frame/tpl-full/tpl-half,
            tpl-quote, tpl-timeline.
            Landing — tpl-nav, tpl-hero-sec/tpl-hero-grid, tpl-principles, tpl-statband, tpl-bleed,
            tpl-cards, tpl-split, tpl-quote-sec, tpl-steps, tpl-final, tpl-footer.
            Imagery — bl-photo-frame, bl-photo, bl-scrim-photo (see the Imagery guideline and the
            Photography component).
Rules:      Medium Blue is the one brand color for emphasis; mint marks a single highlight per slide, not a whole section.
            Photography is grayscale only — see the Imagery guideline before adding a photo.
            A deck is a fixed 1280x720 artboard (bl-slide inside a scaled tpl-stage); a landing page is
            fluid at the standard 768px/1024px breakpoints.
Code:       <section class="bl-slide">
              <div class="tpl-divider">
                <p class="tpl-numeral">03</p>
                <h2>Design principles</h2>
              </div>
            </section>
```

A ready-made 21-slide deck (HTML and a native `.pptx`), a landing page, and a worked example of every layout above ship as a separate template pack alongside this system — ask for it by name if you don't already have a copy. This component and its classes are what let that pack, or a new one, be built and rebuilt from CX Presentation Design System's own tokens rather than a one-off stylesheet.
