An AI-generated message with its author line, an "AI-generated" label, body text with numbered citations, follow-up actions and a source list.

```
Component:  AiMessage
Purpose:    Present generated content so people can tell it is generated and check where it came from.
Parts:      article.bl-ai-msg > .bl-ai-msg__who + p.bl-ai-msg__body (with a.bl-cite) + .bl-ai-msg__meta + ol of li.bl-source
            bl-stream-cursor marks text that is still arriving
Rules:      Label generated content ("AI-generated"). Show sources with numbered citations and say what data was used.
            Make output editable, rejectable, regenerable and undoable, with a Stop control while working.
            The body is limited to 68ch (--layout-prose-max).
Errors:     Refusals and errors say what could not be done and what to try.
A11y:       Do not announce streaming text token by token to screen readers; announce start and completion.
            Each citation is a link with an accessible name ("Source 1"); the number never carries meaning alone.
Code:       <p class="bl-ai-msg__body">Three invoices are overdue.<a class="bl-cite" href="#s1" aria-label="Source 1">1</a></p>
```

The citation chip uses `color-state-selected-bg` with `color-state-selected-border`; a source row is a 1px-bordered row on `color-surface-default`.
