A centered block for a data view with nothing in it: an icon disc, a title, one sentence and a single action.

```
Component:  EmptyState
Purpose:    Explain an empty view and offer the next step.
Parts:      .bl-empty > .bl-empty__icon (icon) + h3 + p + one button
Rules:      Say what this is, why it is empty, and give one action.
            Example: "No invoices yet. Invoices you send will appear here." + [Create invoice]
            The paragraph is limited to 40ch. Do not use an empty state for errors: an error view says what happened and offers a retry.
A11y:       The icon is decorative (aria-hidden). Keep the h3 in sequence with the surrounding headings.
Code:       <div class="bl-empty"><span class="bl-empty__icon"><svg class="bl-icon bl-icon--lg" aria-hidden="true" viewBox="0 0 24 24">...</svg></span>
              <h3>No invoices yet</h3><p>Invoices you send will appear here.</p><button class="bl-btn bl-btn--primary" type="button">Create invoice</button></div>
```
