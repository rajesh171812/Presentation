A 32px label with a strong border and a remove button, for values a person has applied and can take away.

```
Component:  Tag
Purpose:    Show a user-applied label, filter or recipient that can be removed.
Parts:      span.bl-tag > text + button[type=button][aria-label="Remove ..."]
Rules:      Use bl-tag for user-applied, removable labels; use bl-badge for the status of an item.
            The remove button names what it removes ("Remove Design").
A11y:       The remove button is a native <button> in a 24px target with a hover fill; give it an aria-label.
            Border is color-border-strong (4.5:1 or more on surface-default).
Code:       <span class="bl-tag">Design<button type="button" aria-label="Remove Design"><svg class="bl-icon bl-icon--sm" viewBox="0 0 24 24" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button></span>
```
