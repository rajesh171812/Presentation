A bordered stack of native `<details>` disclosures, each with a 48px summary row and a rotating chevron.

```
Component:  Accordion
Purpose:    Reveal secondary content on demand.
Parts:      .bl-accordion > details > summary (label + chevron icon) + .bl-accordion__panel
States:     collapsed, expanded (details[open]), hover, focus
Rules:      Use native details and summary. Summary labels are in sentence case.
A11y:       Native disclosure semantics and keyboard support; the summary is at least 48px tall.
            The chevron rotates 180 degrees when open (duration-fast) and is decorative.
Code:       <div class="bl-accordion"><details><summary>Question<svg class="bl-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></summary>
              <div class="bl-accordion__panel">Answer</div></details></div>
```
