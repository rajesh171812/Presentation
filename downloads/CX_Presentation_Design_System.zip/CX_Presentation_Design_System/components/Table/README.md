A data table in a rounded, scrollable wrapper, with a caption, a tinted header row, row headers, tabular numerals for numbers and a selected-row state.

```
Component:  Table
Purpose:    Compare records across the same attributes.
Parts:      .bl-table-wrap > table.bl-table > caption + thead > tr > th + tbody > tr > th[scope=row] + td
            .is-num on numeric cells (right-aligned, tabular figures); th button for sortable headers
States:     default, row hover, selected row (aria-selected="true" on the tr)
Rules:      Use a table for 5 or more records with the same attributes; fewer, or rich content per item, use a card list.
            Numerals with thousands separators, currency with a symbol and two decimals, unambiguous dates ("14 October 2026").
            Every data view needs loading (skeleton), empty (explain and next action) and error (what happened and retry) states.
Responsive: Mobile: scroll inside a labeled container (role="region" with aria-label and tabindex="0") or turn rows into cards.
            Tablet: hide low-priority columns. Desktop: all columns.
A11y:       Use a <caption>, th scope="col" and scope="row", and aria-sort on the sorted column header.
            Status cells use bl-badge with an icon or word.
Code:       <div class="bl-table-wrap"><table class="bl-table"><caption>Recent invoices</caption>...</table></div>
```
