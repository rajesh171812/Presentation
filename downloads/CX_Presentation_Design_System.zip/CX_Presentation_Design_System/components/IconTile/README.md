The three icon variants of the CX library: rounded tile (default on slides), rounded solid and plain outline.

```
Component:  IconTile
Purpose:    Show an icon as a card, column or section marker on slides and pages.
Variants:   cx-icon-tile (Rounded, ICN-*-RD, default) | cx-icon-tile--solid (Rounded solid, ICN-*-RS) | plain bl-icon (Outline, ICN-*)
Sizes:      cx-icon-tile--sm 32 | default 40 | cx-icon-tile--lg 56
Rules:      Rounded is the default on slides and in the template decks. Rounded solid marks one emphasis point per slide.
            Outline is for icons inside pills, badges, table cells and small labels, where a tile would not fit.
            Icons are Lucide outline, stroke 1.75, from the 111-icon CX library (IDs are ICN- plus the Lucide name).
            An icon never carries meaning alone: pair it with a word.
A11y:       The tile is decorative (the svg has aria-hidden); the adjacent text names the item. Icon ink is 7.9:1 on the tile.
Code:       <span class="cx-icon-tile"><svg class="bl-icon" viewBox="0 0 24 24" aria-hidden="true">…</svg></span>
```
