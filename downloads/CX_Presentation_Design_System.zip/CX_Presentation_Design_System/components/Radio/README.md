A native radio button with a token-styled 20px circle, grouped in a fieldset with a legend.

```
Component:  Radio
Purpose:    Choose exactly one of 2 to 5 options, all visible at once.
Parts:      fieldset.bl-fieldset > legend + label.bl-radio > input[type=radio] + span.bl-radio__box + span (label text)
States:     unselected, selected, hover, focus, disabled
Rules:      Use a radio group for 1 of 2 to 5 options; use bl-select for more. Always wrap the group in a fieldset with a legend.
            Give every input in the group the same name.
A11y:       Native inputs give arrow-key navigation inside the group. Selected shows a filled dot, not color alone.
Code:       <fieldset class="bl-fieldset"><legend>Frequency</legend>
              <label class="bl-radio"><input type="radio" name="freq" checked><span class="bl-radio__box"></span><span>Daily</span></label></fieldset>
```
