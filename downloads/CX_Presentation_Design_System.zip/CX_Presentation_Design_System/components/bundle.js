/* @ds-bundle: {"format":4,"namespace":"CXPresentation","components":[{"name":"Button"}]} */
(function () {
  "use strict";
  var OWN = ["variant", "size", "icon", "loading", "block", "iconOnly", "children", "className"];
  function cx() {
    var out = [];
    for (var i = 0; i < arguments.length; i++) { if (arguments[i]) out.push(arguments[i]); }
    return out.join(" ");
  }
  /* Reference React wrapper from the CX Presentation Design System rules: the pattern to copy for other components. React is a peer (window.React). */
  function Button(props) {
    var React = window.React;
    var variant = props.variant === undefined ? "primary" : props.variant;
    var size = props.size === undefined ? "md" : props.size;
    var loading = !!props.loading;
    var iconOnly = !!props.iconOnly;
    var rest = {};
    for (var k in props) {
      if (Object.prototype.hasOwnProperty.call(props, k) && OWN.indexOf(k) < 0) { rest[k] = props[k]; }
    }
    if (iconOnly && !rest["aria-label"]) { console.warn("Icon-only Button requires aria-label"); }
    var attrs = Object.assign({
      type: "button",
      className: cx("bl-btn", "bl-btn--" + variant, size !== "md" && "bl-btn--" + size,
                    iconOnly && "bl-btn--icon", props.block && "bl-btn--block", props.className),
      "aria-busy": loading || undefined
    }, rest);
    var lead = loading
      ? React.createElement("span", { className: "bl-spinner bl-spinner--sm", "aria-hidden": "true" })
      : props.icon;
    var label = iconOnly ? null : React.createElement("span", null, props.children);
    return React.createElement("button", attrs, lead, label);
  }
  window.CXPresentation = { Button: Button };
})();
