A shimmering placeholder block that holds the layout of content while it loads.

```
Component:  Skeleton
Purpose:    Reserve the layout of content that is loading.
Parts:      .bl-skeleton blocks sized with width and height in a container that has aria-busy="true"
Rules:      Use when the content layout is known; use bl-spinner with a label when it is not. Every data view has a skeleton
            loading state, an empty state and an error state. Size blocks with spacing tokens so they match the real content.
A11y:       Mark the loading region aria-busy="true". Under prefers-reduced-motion the shimmer stops and the block is a flat color-state-hover.
Code:       <div aria-busy="true"><span class="bl-skeleton" style="width: 60%; height: var(--space-4)"></span></div>
```
