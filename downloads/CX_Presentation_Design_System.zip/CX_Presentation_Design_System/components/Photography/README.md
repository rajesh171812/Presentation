Every photograph prints in pure black and white; color stays with the interface. Two building blocks: a crop frame and the image itself, plus an optional scrim for text on top of a photo.

```
Component:  Photography
Purpose:    Show a photograph inside product UI, a deck slide or a landing page without introducing a second color language.
Classes:    bl-photo-frame (crop container, set aspect-ratio or height, overflow: hidden)
            bl-photo (grayscale(1) + object-fit: cover; put this on the <img>)
            bl-scrim-photo (gradient from color-background-default to transparent; only when text sits on the photo)
Rules:      Grayscale only, no duotone or tint. Every photo needs alt text, or alt="" + role="presentation" if decorative.
            Crop to 16:9, 4:3, 3:4 or 1:1 — never stretch or letterbox. A scrim is a gradient, not a contrast guarantee: check it.
Code:       <div class="bl-photo-frame" style="aspect-ratio: 4 / 3">
              <img class="bl-photo" src="photo.jpg" alt="Describe what the photo shows">
            </div>
```

Full rules and the caption/crop table are in the Imagery guideline. The Templates component shows the same treatment used across a full slide deck and landing page.
