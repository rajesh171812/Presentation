Proposed drafts for customer messaging moments shown inside a phone frame: iMessage, SMS, RCS business message and lock-screen notification. All four are Restricted.

```
Component:  Messaging
Purpose:    Show SMS, RCS or notification moments in a journey (SLD-MESSAGING-01).
Patterns:   MSG-IOS-01 iMessage on DEVICE-IPHONE-01 | MSG-SMS-01 SMS on DEVICE-IPHONE-01
            MSG-RCS-01 RCS business message on DEVICE-IPHONE-02 | MSG-NOTIFICATION-01 lock screen on DEVICE-IPHONE-01
Status:     Restricted (proposed draft): every use needs the owner's approval at GATE-02.
Rules:      Native platform colors (bubble blue, SMS green, system grey) are allowed inside MSG-* only; everything around uses tokens.
            Brand name, sender and message copy come from the owner. Never invent regulated or clinical wording.
            Time reads 9:41. No real phone numbers or personal data. Prefer real mockups over these drafts.
A11y:       Give the slide a text summary of the message; the phone image is supporting.
```
