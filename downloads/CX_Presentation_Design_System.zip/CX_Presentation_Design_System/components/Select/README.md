A native `<select>` with the CX Presentation Design System border, radius and a chevron icon, for choosing one of many options.

```
Component:  Select
Purpose:    Choose one option from a long list.
Parts:      bl-field > label.bl-label + .bl-select-wrap > select.bl-select + svg.bl-icon (chevron-down)
States:     default, hover, focus, disabled, invalid
Rules:      Use the native select for choosing 1 of many. Move to a combobox only when the list must be searchable
            (a combobox is specified but not built). For 2 to 5 options use a radio group instead.
            Every select has a visible label; mark optional fields "(optional)".
A11y:       Native element: keyboard and screen readers work unchanged. The chevron is decorative (aria-hidden) and ignores pointer events.
Code:       <div class="bl-field"><label class="bl-label" for="country">Country</label>
              <div class="bl-select-wrap"><select class="bl-select" id="country"><option>United Kingdom</option></select>
              <svg class="bl-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></div></div>
```

Invalid and disabled states follow the input: a 2px `color-status-error-solid` border with an error line below, and `state-disabled-bg` with `text-disabled`.
