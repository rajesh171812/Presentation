A rounded input box for asking an AI feature something, with a borderless textarea, a helper line and a Send or Stop button.

```
Component:  Prompt
Purpose:    Let a person give an instruction or question to an AI feature.
Parts:      form.bl-prompt > textarea + .bl-prompt__bar (helper text + button)
States:     idle (Send), focus (2px ring on the whole box), working (Stop replaces Send)
Rules:      Say what data will be used. Show a Stop control while the AI is working.
            Any action that sends, spends, deletes or shares needs a preview and explicit approval (see bl-plan).
A11y:       The textarea needs an accessible name: use a visually hidden bl-sr-only label. Icon-only Send and Stop buttons carry aria-label.
            The whole box shows the focus ring through :focus-within.
Code:       <form class="bl-prompt"><label class="bl-sr-only" for="q">Ask a question</label><textarea id="q"></textarea>
              <div class="bl-prompt__bar"><span class="bl-caption bl-text-secondary">Uses your invoices.</span>
              <button class="bl-btn bl-btn--primary bl-btn--icon bl-btn--sm" aria-label="Send">...</button></div></form>
```
