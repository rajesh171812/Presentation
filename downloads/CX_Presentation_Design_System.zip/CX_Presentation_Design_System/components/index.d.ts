import * as React from "react";

/** Reference React wrapper for the bl-btn styles (window.CXPresentation.Button). React is a peer dependency. */
export interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "className"> {
  /** Visual variant. One primary per section. Default "primary". */
  variant?: "primary" | "secondary" | "tertiary" | "ghost" | "destructive";
  /** sm 32px, md 40px (default), lg 48px; 40 / 44 / 52 on touch devices. */
  size?: "sm" | "md" | "lg";
  /** Icon shown before the label (a bl-icon SVG). Replaced by a spinner while loading. */
  icon?: React.ReactNode;
  /** Sets aria-busy and shows a small spinner; the button keeps its width and focus. */
  loading?: boolean;
  /** Full width (bl-btn--block). */
  block?: boolean;
  /** Icon-only button: hides the label and requires an aria-label. */
  iconOnly?: boolean;
  className?: string;
  children?: React.ReactNode;
}

export declare const Button: React.FC<ButtonProps>;
