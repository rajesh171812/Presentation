A vertical list of 36px navigation links with group headings and a tinted, marked current item.

```
Component:  Sidenav
Purpose:    Primary navigation for a product area.
Parts:      nav.bl-sidenav > p.bl-sidenav__group + a (icon + label) ; the current link has aria-current="page"
Rules:      Desktop: 264px sidebar (--layout-sidebar-width). Tablet: 72px icon rail (--layout-sidebar-collapsed).
            Mobile: a menu button with an off-canvas panel, or a bottom nav of at most 5 items.
            The current item has a tinted fill, a 3px marker and bold text, so it never relies on color alone.
A11y:       Wrap in a nav with a distinct aria-label. Mark the current link aria-current="page". Icons are decorative.
Code:       <nav class="bl-sidenav" aria-label="Main"><a href="/" aria-current="page"><svg class="bl-icon" aria-hidden="true">...</svg>Overview</a></nav>
```
