A horizontal rule drawn as a 1px `color-border-default` line with `space-5` above and below.

```
Component:  Divider
Purpose:    Separate two blocks of related content.
Rules:      Use a native <hr class="bl-divider">. Prefer spacing to a divider when the grouping is already clear.
            The line is decorative (about 1.3:1 on surface-default), so it never carries meaning alone.
Code:       <hr class="bl-divider">
```
