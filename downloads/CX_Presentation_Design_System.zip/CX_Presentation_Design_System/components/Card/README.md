A bordered surface with 24px padding, an optional title, body and action row, in raised, flat, sunken, interactive and selected variants.

```
Component:  Card
Purpose:    Group rich content about one item.
Parts:      .bl-card > .bl-card__title + .bl-card__body + .bl-card__actions
Variants:   default (shadow-1) | bl-card--flat | bl-card--sunken | bl-card--interactive | bl-card--selected
Rules:      Use a card list for fewer than 5 records or rich content per item; use bl-table to compare 5 or more records.
            Never stack shadows: a card inside a card is bl-card--flat.
            Selected shows a 2px border and tinted fill, so selection never relies on color alone.
Responsive: 1 card per row on mobile, 2 on tablet, 3 to 4 on desktop.
A11y:       Give an interactive card a native link or button as its main control so it is keyboard reachable.
Code:       <article class="bl-card"><h3 class="bl-card__title">Website redesign</h3><p class="bl-card__body">12 tasks, 3 due this week.</p></article>
```

Radius is `radius-lg`, border `color-border-default`, fill `color-surface-default`. The interactive variant lifts to `shadow-2` and `color-border-strong` on hover.
