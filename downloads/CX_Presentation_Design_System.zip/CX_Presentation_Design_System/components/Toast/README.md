A dark, elevated message that confirms an action the person just took, with an optional Undo button.

```
Component:  Toast
Purpose:    Confirm an action just taken.
Parts:      .bl-toast > svg.bl-icon + text + button (Undo or Dismiss)
Rules:      Include Undo when the action is reversible. Max width 420px; fill color-surface-inverse, text color-text-inverse,
            shadow-4; layer it at --z-toast (500). Name the outcome ("Invoice sent").
            Use an alert, not a toast, for a message tied to a place on the page.
A11y:       Render in a live region (role="status"). Give an icon-only Dismiss button an aria-label.
Code:       <div class="bl-toast" role="status"><svg class="bl-icon" viewBox="0 0 24 24" aria-hidden="true">...</svg>
              <span>Invoice sent</span><button class="bl-btn bl-btn--ghost bl-btn--sm" type="button">Undo</button></div>
```
